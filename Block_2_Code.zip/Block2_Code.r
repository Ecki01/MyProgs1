################################################################################
################################################################################
### Begleitender Code zu Block 2
### 16.05.2013
################################################################################
################################################################################

################################################################################
### Hinweis

### hier handelt es sich erstmal nur um dne Code der Blockes, die Erg?nzungen
### Auswahl der NAs, etc werden erst n?chste Woche eingearbeitet.


## Aufr?umen, alle Objekte im Workspace l?schen
rm(list=ls())

## ?berpr?fe das Arbeitsverzeichnis (_w_orking_d_irectory)
getwd()

## Setze das Arbeitsverzeichnis
setwd("Pfad")


## Einlesen der ben?tigten Datens?tze, diese m?ssen alle im gesetzten Arbeits-
## verzeichnis liegen!

# Datensatz TeachingRatings
load("TR.2.RData")                                                              

# Datensatz HairEyeData
load("HairEyeData.RData") 

# Inhalt: Geschlecht, Augenfarbe und Haarfarbe von 592 Statistikstudenten
# basiert auf einen bestehenden R Datensatz (HairEyeColor), 
# umgeformt, so dass es eine Datentabelle darstellt                                                                               


                                                                                
################################################################################
##### Block Wdh.:

## Siehe L?sung Block 1

## Zuweisungen Vektoren - Fragen? ##############################################

## Einlesen von Daten - Fragen? ################################################

ahf1 <- read.csv("augenhaarfarbe.csv")
head(ahf1)

ahf2 <- read.csv2("augenhaarfarbe.csv")
head(ahf2)

# Umbenennen
HairEyeData <- ahf2

# Speichern
save(file="ahf2.RData", "ahf2")

# Aufr?umen
rm("ahf1", "ahf2")



## Datenpr?fung ################################################################

# Passt die Struktur?
str(TR.2)
str(HairEyeData)

# Wie schauen die ersten Beobachtungen aus?
head(TR.2)
head(HairEyeData)

# Levels der kategorialen Variablen:
levels(HairEyeData$Sex)
levels(HairEyeData$Hair)
levels(HairEyeData$Eye)

# Umbenennen der Levels von Sex
HairEyeData$Sex.1  <-  factor(HairEyeData$Sex, levels = c("m", "w"), labels = c("m?nnlich","weiblich"))
levels(HairEyeData$Sex) # geklappt!

# oder:

?recode # gibt es nicht, Internetrecherche -> library("car") notwendig

install.Rtools()
library("Rtools")
install.packages("Datacar")
library("Datacar")

install.packages("car")
library("car")
recode()
HairEyeData$Sex.2 <- recode(HairEyeData$Sex, recodes=' "m"="m?nnlich" ; "w"="weiblich" ')


.libPaths()



################################################################################
##### Theorie Ma?zahlen

## kein Code

################################################################################
##### Univariate Deskription

################################################################################
### Kategoriale Merkmale

## Tabellen ####################################################################

# absolute H?ufigkeiten 

# Tabelle der Variable Geschlecht, Aussage: Wieviele Kurse hatten einen weiblichen Dozenten, ausgegeben werden die Absolutzahlen

( tab.Geschlecht <- table(TR.2$Geschlecht) )                                     
                                                                                
# die Tabelle wird im Objekt tab.Geschlecht gespeichert

# Tabelle der Variable Kurstyp, Aussage: Welche Kurstypen hatten die Kurse, ausgegeben werden die Absolutzahlen
( tab.Kurstyp <- table(TR.2$Kurstyp) )                                        
                                                                                
# die Tabelle wird im Objekt tab.Kurstyp gespeichert


# Tabelle der Haarfarbe
( tab.Hair <- table(HairEyeData$Hair) )                                    

# Tabelle der Augenfarbe (Tabelle S. 18)
( tab.Eye <- table(HairEyeData$Eye) )   

## relative H?ufigkeiten

# Zwei Wege:
#A: relative Werte / Gesamtzahl
dim(HairEyeData)[1] # Gesamtzahl
(tab.Hair/dim(HairEyeData)[1])

#B:
tab.Eye.p <- prop.table(tab.Hair)

# prop.tab() muss auf Tabellenobjekt angewandt werden, es w?rde auch gehen: prop.table( table(HairEyeData$Eye)) )

# Runden einer Tabelle auf 2 Nachkommastellen:
round(tab.Eye.p, 2) 

# Angabe in Prozent:
round(tab.Eye.p, 2) * 100

# zum Vergleich: summary() 
summary(HairEyeData$Hair)                                                        
# bei Faktorvariablen berechnet summary() die Tabelle


################################################################################
# Ma?zahlen
################################################################################



# Modus ########################################################################

which.max(tab.Eye)   # gibt die Kategorie zur?ck

max(tab.Eye) 	       # gibt die Maximalzahl zur?ck                                                                   

                                                             


# kumulative Summe
cumsum(tab.Eye.p)                                                               
# kumulative Summe berechnen (es wird jedes Element aufsummiert)

# Achtung beim Runden (hier 1. Nachkommastelle zur Demonstration)

cumsum(round(tab.Eye.p,1))                                                      
# Summe > 1

round(cumsum(tab.Eye.p), 1)                                                     
# Summe == 1


# Median #######################################################################

tab.eval <- table(TR.2$Evaluierung2)
median(tab.eval)                                                                # Achtung: hier wird zwar keine Fehlermeldung zur?ckgegeben, aber es handelt sich um den Median der Tabellenkategorien, nicht um den Median der Daten!

## ?ber kum. H?ufigkeiten
cumsum(tab.eval)

median(as.numeric(TR.2$Evaluierung2))                                           # Der Median geht nicht von Faktorvariablen, daher muss dies Variable in eine nummerische Variable umkodiert werden (as.numeric() )

# Der Median entspricht der 4 Kategorie, dass vierte Level ist "gut" - Der Median ist daher "gut"
levels(TR.2$Evaluierung2)

# Mittlerer Wert - Rechts von Median liegen 50% der Daten, links davon auch

dim(TR.2) # ist ungerade
(dim(TR.2)[1]-1)/2 # der 231. Wert ist der Mittlere

# Wie gro? ist Evaluarierung an dieser Stelle, wenn die Daten geordnet sind?
sort(TR.2$Evaluierung2)[231]


################################################################################
## Grafiken
################################################################################


# S?ulen-/Balkendiagramme ######################################################

# S?ulendiagramm Geschlecht, abs. H?ufigkeiten (Standardoption bei barplot)
barplot(tab.Geschlecht)                                                         

# Balkendiagramm Geschlecht, abs. H?ufigkeiten
barplot(tab.Geschlecht,  horiz = TRUE)                                          

# S?ulendiagramm Geschlecht, rel. H?ufigkeiten
barplot(prop.table(tab.Geschlecht))                                             

# S?ulendiagramm Geschlecht, rel. H?ufigkeiten, y-Achse geht von 0 bis 1
barplot(prop.table(tab.Geschlecht), ylim = c(0,1))                              


# Titel (main = "text") und Achsenbeschriftung (xlab [x-Achse] bzw. ylab [y-Achse] = "text") wurde hinzugef?gt
barplot(prop.table(tab.Geschlecht), ylim = c(0,1), main = "Verh?ltnis Geschlecht", xlab = "Geschlecht", ylab = "rel. H?ufigkeit")
                                                                                
# F?r die Augenfarbe
barplot(tab.Eye.p , ylim = c(0,1), main = "Verteilung Augenfarbe", xlab = "Augenfarbe", ylab = "rel. H?ufigkeit")



# Mosaikplot ###################################################################

# Aufteilung der Fl?che nach den Anteilen
mosaicplot(tab.Geschlecht)                                                      

# Trennungsrichtung wurde auf horizontal (dir = "h") ge?ndert
mosaicplot(tab.Geschlecht, dir = "h")                                           


# Titel hinzugef?gt
mosaicplot(tab.Eye, main="Mosaikplot Augenfarbe")



# Kreisdiagramm ################################################################

# Funktion zum Zeichnen von Kreisdiagrammen
pie(tab.Geschlecht)                                                             

pie(tab.Eye)




################################################################################
### metrische Merkmale
################################################################################

################################################################################
## Tabelle
( tab.Alter   = table(TR.2$Alter) )                                             # Tabelle f?r Alter


################################################################################
## F?nf (6) Punkte Zusammenfassung
sort(TR.2$Alter)                                                                # sort - sortiert die Daten nach der Reihe (erzeugt die sortierte Urliste)
sort(unique(TR.2$Alter))                                                        # unique - Einzigartig, l?scht doppelte Eintr?ge, gut um einen besseren ?berblick zu bekommen, wieviele Auspr?gungen es ?berhaupt gibt

min(TR.2$Alter)                                                                 # Minimum
max(TR.2$Alter)                                                                 # Maximum


max(table(TR.2$Alter))                                                          # H?ufigkeit der maximalen Auspr?gung
which.max(table(TR.2$Alter))                                                    # Modus, Auspr?gung mit der gr??ten H?ufigkeit: Macht iA. aber wenig Sinn, nur bei wenigen Auspr?gungen und ganzen Zahlen

mean(TR.2$Alter)                                                                # arithemetisches Mittel

median(TR.2$Alter)

quantile(TR.2$Alter, c(.25))                                                    # 25% Quantil
quantile(TR.2$Alter, c(.75))                                                    # 75% Quantil
quantile(TR.2$Alter, c(.25,.50,.75))                                            # wenn man einen Vektor ?bergibt, k?nnen mehrere Quantile gleichzeitig berechnet werden, es wird ein Vektor zur?ckgegeben.

(deskr.Alter       = c(min(TR.2$Alter),quantile(TR.2$Alter, c(.25)),median(TR.2$Alter), mean(TR.2$Alter), quantile(TR.2$Alter, c(.75)), max(TR.2$Alter)))
(deskr.Alter.names = c("Min" = min(TR.2$Alter),quantile(TR.2$Alter, c(.25)),"Median" = median(TR.2$Alter), "Mean" = mean(TR.2$Alter), quantile(TR.2$Alter, c(.75)), "Max" = max(TR.2$Alter)))
                                                                                # "Min" = wei?t den Objekt einen Namen zu, steht dann Oberhalb als Elementbeschriftung (oder auch Spaltenbeschriftung)
                                                                                # Wenn ein Objekt bereits einen solche Namen hat (z.B. bei quantile) wird dieser verwendet
summary(TR.2$Alter)
round(deskr.Alter.names, 2)

################################################################################
## 2 Punkte Zusammenfassung

mean(TR.2$Alter)                                                                # arithmetisches Mittel

var(TR.2$Alter)                                                                 # Varianz

sd(TR.2$Alter)                                                                  # Standardabweichung
sqrt(var(TR.2$Alter) )                                                          # Umweg ?ber Wurzel der Varianz

# Erg?nzung:: manuelle Berechung, nicht wirklich notwendig
1/length(TR.2$Alter) * sum( (TR.2$Alter - mean(TR.2$Alter))^2 )                 # empirische Varianz mit 1/n - nicht identisch mit var(TR.2$Alter)

1/(length(TR.2$Alter)-1) * sum( (TR.2$Alter - mean(TR.2$Alter))^2 )             # Stichprobenvarianz, identisch mit var(TR.2$Alter)

################################################################################
### Grafiken

################################################################################
## Histogramm

hist(TR.2$Alter)                                                                # "Standard-" Histogramm

hist(TR.2$Alter, breaks = 20)                                                   # mit breaks k?nnen die Anzahl der Zellen f?r das Histogramm definiert werden, die ?bergebene Anzahl wird aber nicht genau/direkt verwendet

hist(TR.2$Alter, breaks = c(29,40,45,50,55,60,73))                              # mit breaks k?nnen eigene Bruchpunkte festgelegt werden (Achtung, der erste Punkte sollte das Minimum der Daten sein, der letzte das Maximum)
                                                                                # au?er es gibt gute inhaltliche Gr?nde f?r andere Grenzen


hist(TR.2$Alter, breaks = c(29,40,45,50,55,73))                                 # Auswirkung anderer Grenzen (echte Grenzen in den Daten)
hist(TR.2$Alter, breaks = c(20,40,45,50,55,80))                                 # andere Grenzen, man beobachte, wie die H?he an den R?ndern niedriger wird (jedoch, da auch breiter, ist die Fl?che gleich)

# f?r Folien
hist(TR.2$Alter, col = "gray", main = "Histogramm des Alters", xlab = "Alter", ylab = "H?ufigkeit")  # mit Farben und ?berschrift

################################################################################
## Dichtesch?tzung

hist(TR.2$Alter, freq = FALSE)                                                  # freq, Darstellungstyp der H?ufigkeit auf der y-Achse, wenn TRUE (Standard) werden H?ufigkeitsdichten (Anzahlen) angezeigt, wenn
                                                                                # FALSE wird eine Wahrscheinlichkeitsdichte (vergl mit relativen H?ufigkeiten) angezeigt.

lines(density(TR.2$Alter))                                                      # density() berechnet eine Dichtesch?tzung f?r eine metrische Variable
                                                                                # lines() erg?nzt einen Linienzug zu einer bestehenden Grafik
                                                                                # lines(density()) in einen Histogramm geht nur, wenn freq = FALSE beim Erstellen
                                                                                # des Histogrammms gew?hlt wurde.

# f?r Folien
hist(TR.2$Alter, col = "gray", main = "Histogramm des Alters", xlab = "Alter", ylab = "Dichte", freq = FALSE, ylim = c(0,0.04))
                                                                                # ylim ist notwendig, da ansonsten die Dichtesch?tzung abgeschnitten wird
lines(density(TR.2$Alter), lwd = 2)                                             # Zeichnen der Dichtesch?tzung, Linienst?rke (lwd) vergr??tert

################################################################################
## Boxplot
summary(TR.2$Alter)

boxplot(TR.2$Alter)                                                             # Zeichnet ein Boxplot
points(mean(TR.2$Alter))                                                        # f?gt den Mittelwert als Punkt zur Grafik hinzu, erg?nzt ?hnlich wie lines() eine bestehende Grafik

boxplot(TR.2$Alter, ylim = c(20,80), main  = "Alter der Kursdozenten")          # mit festgelegter y-Achse und Titel

Alter.2 = c(TR.2$Alter, 120)                                                    # Erzeugen eines neuen Vektors mit einen Ausrei?erwert
boxplot(Alter.2)

# Darstellung eines Problems bei bimodalen (zweigipfligen Verteilungen) - sind im Boxplot nicht erkennbar
Bsp.Problem = c(rnorm(100,-2,1), rnorm(100,2,1))                                # Erzeugen einer Variablen zur Demonstrationszwecken, Code muss nicht verstanden werden

boxplot(Bsp.Problem)                                                            # beim Boxplot nichts besonderes zu erkennen

hist(Bsp.Problem, freq = FALSE)                                                 # Histogramm und Dichtesch?tzung zeigen eindeutig die zweigipflige Struktur
lines(density(Bsp.Problem))

# f?r Folien
boxplot(TR.2$Alter, ylim = c(20,120) , main  = "Alter der Kursdozenten", col = "gray", ylab = "Alter in Jahren")
boxplot(Alter.2,    ylim = c(20,120), main  = "Alter der Kursdozenten (mit Ausrei?er)", col = "gray", ylab = "Alter in Jahren")

boxplot(Bsp.Problem, main = "Boxplot bei bimodaler Verteilung", col = "gray")

hist(Bsp.Problem, freq = FALSE, main = "Histogramm bei bimodaler Verteilung", ylab = "Dichte", col = "gray")
lines(density(Bsp.Problem) ,lwd = 2)