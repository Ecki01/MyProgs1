################################################################################
### Beispielcode f�r Block 1
### 14.05.2013
### Johanna Brandt
################################################################################


################################################################################
## Vorbereitung der Arbeitsumgebung
################################################################################

### Wie lautet das aktuelle Arbeitsverzeichnis?
getwd()

### Setze ein Arbeitsverzeichnis
Pfad = "Y:/Lehre/Kurs_Statistik_R_Studienbeitraege/Block 1 Daten"

setwd(Pfad)

### Achtung: / oder \\ f�r die Pfadangabe, im Allgemeinen wird \ f�r 'Sonderzeichen' genutzt



### Zeige alle Objekte im Workspace
objects() # oder
ls()

### L�sche alle Objekte im Workspace
rm(list=ls())


################################################################################
## R als Taschenrechner
################################################################################

### Grundrechenarten und Klammern ##############################################

1+2

1*2

4-2*7

(4-2)*7

1/2

1/2 + 3/4


### Weitere Funktionen #########################################################

1/2^2     # Potenz
sqrt(16)  # Wurzel
exp(2)    # Exponens
log(7)    # Logarthmus


### Funktionen in R -- Hilfe ###################################################

?log 

# Welcher Logarithmus wird berechnet? 
# Wie kann ich den Logarithmus zur Basis 10 berechnen?



################################################################################
## Zuweisungen und Vektoren
################################################################################

### Einfach Zuweisungen ########################################################

a <- 5
a

a = 7
a

b <- 2+5

a+b

### Vektoren ###################################################################

# c() f�r concatenate
# rep() f�r replicate
# seq() f�rr sequence

1:3

c(1,2,3)

c(1,3,6,100)

rep(1:4, each = 2)

rep(1:4, times = 2)

seq(from = 0, to = 1, by = 0.2)

seq(from = 0, to = 1, length.out = 5)

### Abspeichern der Sequenzen in Objekten (Vektoren) ###########################
a <- 1:3
a


### Rechnen mit Vektoren #######################################################

a <- 1:3

a + 3

a * 3

a^2


################################################################################

### Einlesen der Daten

### read.table: Standardfunktion, viele Optionen m�glich, Infos unter ?read.table

### read.csv: Funktion zum Einlesen von csv-Dateien 
dat1 = read.csv("Daten.csv")   

### Hinweis1
### Definition von NA-Termen: Option: na.strings = "NA"

dat2 = read.csv("Daten.csv", na.strings = -99)

### Hinweis2: Laden andererer Datenformate

# Paket zum Laden von externen Datenformaten/Datenbanken, z.B. SPSS Daten: read.spss
library(foreign)  

# Paket zum Laden von xls-Dateien
library(gdata)  # und Funktion read.xls()

# einige GUI haben aber spezielle Import-Menues


################################################################################
### Kontrolle der Daten
################################################################################

str(dat1)        # Struktur der Daten

head(dat1, 2)    # Die ersten beiden Zeilen
head(dat1)

tail(dat1)       # Die letzten Zeilen

fix(dat1)        # �ffnet einen Dateneditor

dim(dat1)        # Dimenension der Form Anzahl Zeilen, Anzahl Spalten
nrow(dat1)       # Anzahl Zeilen
ncol(dat1)       # Anzahl Spalten

names(dat1)      # Variablennamen


################################################################################
### Umformen, Levels, Labels, ...
################################################################################

dat3 = dat2

# Geschlecht als nominale Variable, in R: Faktor-Variable
dat3$Geschlecht = as.factor(dat2$Geschlecht) 
str(dat3)

# Namen f�r die beiden Auspr�gungen
dat3$Geschlecht = factor(dat2$Geschlecht, levels = c(0,1), labels = c("w","m"))
str(dat3)

levels(dat3$Geschlecht)     # Ausgabe der Namen der Kategorien
nlevels(dat3$Geschlecht)    # Anzahl der Kategorien

################################################################################
### Zugriff auf Elemente
################################################################################


## Positivauswahl
dat3[1,1]                                         # [Zeilen, Spalte]

dat3[6,2]
dat3[2,6]

dat3[1,]                                          # Auch f�r ganze Zeilen und Spalten m�glich
dat3[,2]

dat3[,"Haarl�nge"]                                # Zugriff auf Variablen auch �ber Namen m�glich

dat3[,c("Geschlecht","Haarl�nge")]
dat3[,c(2,6)]


## Auswahl von Daten, die bestimmte Kriterien erf�llen
## mit logischen Vektoren oder Indexvektoren 
dat3[which(dat3$Geschlecht == "w"), "Haarl�nge"]   # Die Haarl�nge von Frauen
dat3[dat3$Geschlecht == "w", "Haarl�nge"]          # alternative ohne which()

dat3[1:3,1:6]
dat3[c(1,3), c(1,3,5)]

## Negativauswahl
dat3[,-c(2,6)]

# macht meist nur bei Spalten Sinn, da f�r Zeilen die Bedingung nur umgedreht werden muss
dat3[dat3$Geschlecht != "w", "Haarl�nge"]

### Befehl subset
subset(dat3, select = "Haarl�nge")
subset(dat3, Geschlecht == "m", select = Haarl�nge)
subset(dat3, Geschlecht == "m", select = -Haarl�nge)

################################################################################
### Berechnen neuer Variablen
################################################################################

# Berechnung einer Variablen Score_VK 
# (Score Vorkenntnisse = Summe der drei Spalten Vorkenntnisse)

dat3$Score_VK = dat3$Vorkenntnisse.R + dat3$Vorkenntnisse.Statistik + dat3$Vorkenntnisse.Software

dat3    # da einmal NA wird die gesamt Summe auf NA gesetzt

# Alternativen (zuerst subset bilden, dann die Zeilensummen berechnen)
dat3$Score_VK = rowSums(subset(dat3, select = c(Vorkenntnisse.R,Vorkenntnisse.Statistik,Vorkenntnisse.Software)))

# Befehle rowSums, colSums
# Befehle Colsums


################################################################################
### weitere Datensatzbearbeitungen
################################################################################


### Hinweis: attach, detach

### rbind, cbind, merge: Zusammenf�gen von Vektoren/data.frames


################################################################################
### Speichern und Aufr�umen
################################################################################

save(dat3, file="dat3.RData")   # auch write.table, write.csv - analog zum Import

rm(list = ls())
setwd(Pfad)                     # auch die Variable Pfad ist gel�scht

load(file="dat3.RData")
